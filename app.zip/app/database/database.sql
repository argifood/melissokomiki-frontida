-- Create database
-- CREATE DATABASE IF NOT EXISTS beesness_better DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
CREATE DATABASE IF NOT EXISTS beesness_better DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
SET NAMES 'utf8';

-- Select database
--USE dmitrovg513273_beesness_better_app;
USE beesness_better;

CREATE TABLE language (
   language_id    INT            NOT NULL AUTO_INCREMENT,
   language_name  VARCHAR(32)    NOT NULL,
   language_flag  VARCHAR(96)    NOT NULL,
   PRIMARY KEY (language_id),
   UNIQUE KEY idx_language_name (language_name)
);

CREATE TABLE beehive_cluster (
    cluster_id           INT            NOT NULL AUTO_INCREMENT,
    customer_id          INT            NOT NULL,
    cluster_size         INT            NOT NULL,
    cluster_name         VARCHAR(32)    NOT NULL,
    PRIMARY KEY (cluster_id)
);

CREATE TABLE cluster_location (
    location_id          INT            NOT NULL,
    cluster_id           INT            NOT NULL,
    cluster_dms_lon          VARCHAR(16)    NOT NULL,
    cluster_dms_lat          VARCHAR(16)    NOT NULL,
    cluster_city         VARCHAR(32)    NOT NULL,
    cluster_state_id     INT            NOT NULL,
    cluster_country_id   INT            NOT NULL,
    s_date             DATETIME       NOT NULL,
    e_date             DATETIME       NOT NULL,
    associated_cost    INT       NOT NULL,
    associated_production    INT       NOT NULL,
    PRIMARY KEY (location_id, cluster_id)
);

CREATE TABLE beehives (
   beehive_id           INT             NOT NULL AUTO_INCREMENT,
   cluster_id           INT             NOT NULL,
   beehive_name         VARCHAR(32)     NOT NULL,
   PRIMARY KEY (beehive_id)
);

CREATE TABLE beehive_health_status (
   beehive_health_data_id   INT         NOT NULL AUTO_INCREMENT,
   beehive_id               INT         NOT NULL,
   beehive_uc_battery       FLOAT       NOT NULL,
   beehive_gsm_battery      FLOAT       NOT NULL,
   beehive_RSSI             FLOAT       NOT NULL,
   added_on                 DATETIME    NOT NULL,
   PRIMARY KEY (beehive_health_data_id, beehive_id)
);

CREATE TABLE beehive_data (
    beehive_data_id INT     NOT NULL AUTO_INCREMENT,
    beehive_id      INT     NOT NULL,
    weight          FLOAT   NOT NULL,    
    int_temp        FLOAT   NOT NULL,  
    ext_temp        FLOAT   NOT NULL,  
    ext_hum         FLOAT   NOT NULL,  
    lum             FLOAT   NOT NULL,       
    Latitude        FLOAT   NOT NULL,  
    Longtitude      FLOAT   NOT NULL,
    added_on        DATETIME       NOT NULL,
   PRIMARY KEY (beehive_data_id, beehive_id)
);

CREATE TABLE beehive_actions (
    action_id INT       NOT NULL AUTO_INCREMENT,
    beehive_id INT      NOT NULL,
    description TEXT    NOT NULL,
    added_on DATETIME   NOT NULL,
    PRIMARY KEY (action_id)
);

CREATE TABLE country (
    country_id            INT             NOT NULL AUTO_INCREMENT,
    name                  VARCHAR(64)     NOT NULL,
    iso_code_2            CHAR(2)         NOT NULL,
    iso_code_3            CHAR(3)         NOT NULL,
    address_format_id     INT             NOT NULL,
    PRIMARY KEY (country_id),
    KEY IDX_COUNTRY_NAME (name)
);

CREATE TABLE country_state (
    state_id    INT     NOT NULL,
    country_id  INT     NOT NULL,
    state_name  TEXT    NOT NULL,
    PRIMARY KEY (state_id)
);

CREATE TABLE customer (
    customer_id             INT             NOT NULL AUTO_INCREMENT,
    created_on              DATETIME        NOT NULL,
    gender                  CHAR(1)         NOT NULL,
    first_name              VARCHAR(32)     NOT NULL,
    last_name               VARCHAR(32)     NOT NULL,
    nickname                VARCHAR(32),
    email                   VARCHAR(96),
    password                VARCHAR(64)     NOT NULL,
    birthday                DATETIME        DEFAULT '0000-00-00 00:00:00' NOT NULL,
    street_address          VARCHAR(64)     NOT NULL,
    city                    VARCHAR(32)     NOT NULL,
    state_id                INT             ,
    postcode                VARCHAR(10)     NOT NULL,
    country_id              INT             ,
    shipping_region_id      INT             ,
    company                 VARCHAR(64),
    phone                   VARCHAR(32)     NOT NULL,
    mobile                  VARCHAR(32)     NOT NULL,
    company_name            VARCHAR(64),
    company_address         VARCHAR(64),
    profession              VARCHAR(64),
    vat_registration        VARCHAR(16),
    tax_office              VARCHAR(32),
    newsletter              CHAR(1),
    password_recover_id     VARCHAR(32),
    password_recover_start  DATETIME,
    bee_id                  VARCHAR(16),
    PRIMARY KEY (customer_id),
    UNIQUE KEY idx_customer_email (email)
);

CREATE TABLE administrator (
    administrator_id    INT             NOT NULL AUTO_INCREMENT,
    first_name          VARCHAR(32)     NOT NULL,
    last_name           VARCHAR(32)     NOT NULL,
    email               VARCHAR(64),
    password            VARCHAR(96)     NOT NULL,
    created_on          DATETIME        NOT NULL,
    last_login          DATETIME,
    status              TINYINT         NOT NULL DEFAULT 0,
    language_id         INT,
    seminars_per_page   INT,
    reviews_per_page    INT,
    questions_per_page  INT,
    reports_per_page    INT,
    offers_per_page     INT,
    PRIMARY KEY (administrator_id),
    UNIQUE KEY idx_administrator_email (email)
);

CREATE TABLE permission (
    permission_id       INT             NOT NULL AUTO_INCREMENT,
    name                VARCHAR(32)     NOT NULL,
    description         VARCHAR(255),
    code_name           VARCHAR(32)     NOT NULL,
    PRIMARY KEY (permission_id),
    KEY idx_code_name (code_name)                     
);

CREATE TABLE administrator_permission (
    administrator_id        INT         NOT NULL,
    permission_id           INT         NOT NULL,
    PRIMARY KEY (administrator_id, permission_id)
);

CREATE TABLE meteo_station (
    station_id         INT NOT NULL,
    station_name       VARCHAR(32) NOT NULL,
    station_city       VARCHAR(32) NOT NULL,
    station_state      VARCHAR(32) NOT NULL,
    station_elev       VARCHAR(32) NOT NULL,
    station_lat        VARCHAR(32) NOT NULL,
    station_long       VARCHAR(32) NOT NULL,
    PRIMARY KEY (station_id)
);    

CREATE TABLE meteo_station_data (
    data_entry_id        INT NOT NULL AUTO_INCREMENT,
    station_id      INT NOT NULL,
    meteo_month     VARCHAR(8) NOT NULL,
    meteo_year      VARCHAR(8) NOT NULL,
    meteo_day       VARCHAR(8) NOT NULL,
    mean_temp       FLOAT  NOT NULL,    
    high_temp       FLOAT  NOT NULL,  
    high_temp_time  FLOAT  NOT NULL,  
    low_temp        FLOAT  NOT NULL,  
    low_temp_time   FLOAT  NOT NULL,  
    heat_deg_days   FLOAT  NOT NULL,  
    cool_deg_days   FLOAT  NOT NULL,  
    rain            FLOAT  NOT NULL,  
    avg_wind_speed  FLOAT  NOT NULL,  
    max_wind_speed  FLOAT  NOT NULL,  
    max_wind_speed_time FLOAT  NOT NULL,  
    dom_dir         VARCHAR(8)  NOT NULL,  
    added_on        DATETIME       NOT NULL,
    PRIMARY KEY (data_entry_id)
);

-- Change DELIMITER to $$
DELIMITER $$

CREATE PROCEDURE language_get_languages()
BEGIN
   SET NAMES 'utf8';
   SELECT     *
   FROM       language;
END$$

CREATE PROCEDURE language_get_language(IN inLanguageId INT)
BEGIN
   SELECT     language_name, language_flag
   FROM       language
   WHERE      language_id = inLanguageId;
END$$

CREATE PROCEDURE language_get_by_name(IN inLanguageName VARCHAR(32))
BEGIN
   SELECT     language_id, language_name, language_flag
   FROM       language
   WHERE      language_name = inLanguageName;
END$$


CREATE PROCEDURE beehive_add_data_entry(IN inBeehiveId INT, IN inBeehiveWeight FLOAT, IN inBeehiveIntTemp FLOAT, IN inBeehiveExtTemp FLOAT, IN inBeehiveHumidity FLOAT, IN inBeehiveLuminosity FLOAT, IN inBeehiveLatitude FLOAT, IN inBeehiveLongtitude FLOAT)
BEGIN
    INSERT 
    INTO    beehive_data (beehive_id, weight, int_temp , ext_temp , ext_hum, lum, Latitude, Longtitude, added_on)
    VALUES  (inBeehiveId, inBeehiveWeight, inBeehiveIntTemp, inBeehiveExtTemp, inBeehiveHumidity, inBeehiveLuminosity, inBeehiveLatitude, inBeehiveLongtitude, NOW());
END$$

CREATE PROCEDURE beehive_get_data_entry(IN inBeehiveId INT, IN inStartDate DATE, IN inEndDate DATE)
BEGIN
    SELECT * 
    FROM    beehive_data 
    WHERE   beehive_id = inBeehiveId AND (added_on BETWEEN inStartDate AND inEndDate);
END$$

CREATE PROCEDURE beehive_get_beehive_data(IN inBeehiveId INT, IN inStartDate DATE, IN inEndDate DATE)
BEGIN
    SELECT * 
    FROM    beehive_data 
    WHERE   beehive_id = inBeehiveId AND (added_on BETWEEN inStartDate AND inEndDate);
END$$

-- Get Clusters belonging to the same customer
CREATE PROCEDURE beehive_get_clusters(IN inBeehiveOwnerId INT)
BEGIN
    SELECT max(added_on) AS added_on, cl.cluster_id, cl.cluster_city, b.customer_id, b.cluster_size, b.cluster_name, cl.location_id, cl.cluster_dms_lon, cl.cluster_dms_lat, cl.cluster_city, cl.cluster_state_id, cl.cluster_country_id 
    FROM cluster_location cl inner join beehive_cluster b ON b.cluster_id=cl.cluster_id GROUP BY cl.cluster_id;
END$$

-- Get Clusters current location belonging to the same customer
CREATE PROCEDURE beehive_get_clusters_current_location(IN inBeehiveOwnerId INT)
BEGIN
    SELECT bc.customer_id, location_id, u4.cluster_id, cluster_city, cluster_name, cluster_dms_lon, cluster_dms_lat, cluster_size FROM
    (SELECT u1.* from cluster_location u1 JOIN (SELECT cluster_id, max(location_id) AS location_id FROM cluster_location GROUP BY cluster_id) u2 USING(cluster_id,location_id)) u4 INNER JOIN beehive_cluster bc ON u4.cluster_id=bc.cluster_id WHERE bc.customer_id=inBeehiveOwnerId;
END$$


-- Get Cluster Name
CREATE PROCEDURE beehive_get_cluster_name(IN inClusterId INT)
BEGIN
    SELECT cluster_name 
    FROM   beehive_cluster
    WHERE  cluster_id = inClusterId;
END$$

-- Get Cluster Location
CREATE PROCEDURE beehive_get_cluster_location(IN inClusterId INT)
BEGIN
    SELECT cluster_dms_lon, cluster_dms_lat,location_id 
    FROM   cluster_location
    WHERE  cluster_id = inClusterId
    ORDER BY added_on DESC LIMIT 1;
END$$

-- Get Beehives belonging to the same cluster
CREATE PROCEDURE beehive_get_cluster_beehives(IN inClusterId INT)
BEGIN
    SELECT * 
    FROM   beehives
    WHERE  cluster_id = inClusterId;
END$$

CREATE PROCEDURE beehive_count_cluster_beehives(IN inClusterId INT)
BEGIN
    SELECT count(*) as count 
    FROM   beehives
    WHERE  cluster_id = inClusterId;
END$$

-- Get Beehives belonging to the same cluster
CREATE PROCEDURE beehive_get_cluster_locations(IN inClusterId INT)
BEGIN
    select cl.cluster_id, cl.cluster_city, cl.associated_cost , cl.associated_production, cl.s_date,cl.e_date from beehive_cluster as bc inner join cluster_location cl where cl.cluster_id=inClusterId;
END$$

CREATE PROCEDURE beehive_add_health_status_entry(IN inBeehiveId INT, IN inBeehiveuCBattery FLOAT, IN inBeehivegsmBattery FLOAT, IN inBeehiveRSSI FLOAT)
BEGIN
    INSERT 
    INTO    beehive_health_status (beehive_id, beehive_uc_battery, beehive_gsm_battery, beehive_RSSI, added_on)
    VALUES  (inBeehiveId, inBeehiveuCBattery, inBeehivegsmBattery, inBeehiveRSSI, NOW());
END$$

-- Create customer_check_existance stored procedure
CREATE PROCEDURE customer_check_login_info(IN inEmail VARCHAR(96), 
                                            IN inPassword VARCHAR(64))
BEGIN
    DECLARE customerId INT;
    DECLARE checkStatus INT;
    DECLARE customerFirstName VARCHAR(32);
    DECLARE customerLastName VARCHAR(32);
    DECLARE customerPassword VARCHAR(64);
    DECLARE customerPasswordRecoverId VARCHAR(32);
    
    SELECT  customer_id, first_name, last_name, password, 
            password_recover_id
    FROM    customer 
    WHERE   email = inEmail
    INTO    customerId, customerFirstName, 
            customerLastName, customerPassword,
            customerPasswordRecoverId;

    IF customerId IS NULL THEN
        SET checkStatus = 2;
    ELSEIF customerPassword != inPassword THEN
        SET checkStatus = 1;
    ELSEIF customerPasswordRecoverId IS NOT NULL THEN
        SET checkStatus = 3;
    ELSE
        SET checkStatus = 0;
    END IF;
    
    SELECT  customerId AS customer_id, 
            customerFirstName AS first_name,
            customerLastName AS last_name,
            checkStatus AS check_status;
END$$

-- Create customer_add stored procedure
CREATE PROCEDURE customer_add(IN inGender CHAR(1),
                                IN inFirstName VARCHAR(32),
                                IN inLastName VARCHAR(32), 
                                IN inEmail VARCHAR(96), 
                                IN inPassword VARCHAR(64),
                                IN inStreetAddress VARCHAR(64),
                                IN inCity VARCHAR(32),
                                IN inStateId INT,
                                IN inPostcode VARCHAR(10),
                                IN inCountryId INT,
                                IN inPhone VARCHAR(32),
                                IN inMobile VARCHAR(32))
BEGIN
    INSERT 
    INTO    customer (created_on, gender, first_name, last_name, 
                email, password, 
                street_address, city, state_id, 
                postcode, country_id, 
                phone, mobile)
    VALUES  (NOW(), inGender, inFirstName, inLastName,  
                inEmail, inPassword,  
                inStreetAddress, inCity, inStateId, 
                inPostcode, inCountryId, 
                inPhone, inMobile);
  
    SELECT LAST_INSERT_ID();
END$$

-- Create utils_get_countries stored procedure
CREATE PROCEDURE utils_get_countries()
BEGIN
    SELECT  *
    FROM    country; 
END$$

-- Create utils_get_country stored procedure
CREATE PROCEDURE utils_get_country(IN inCountryId INT)
BEGIN
    SELECT  name, iso_code_2, iso_code_3, address_format_id
    FROM    country
    WHERE   country_id = inCountryId; 
END$$

-- Create utils_get_country_states stored procedure
CREATE PROCEDURE utils_get_country_states(IN inCountryId INT)
BEGIN
    SELECT  state_id, state_name
    FROM    country_state
    WHERE   country_id = inCountryId; 
END$$

-- Create utils_get_states stored procedure
CREATE PROCEDURE utils_get_states()
BEGIN
    SELECT  state_id, state_name, country_id
    FROM    country_state;
END$$

-- Create utils_get_state stored procedure
CREATE PROCEDURE utils_get_state(IN inStateId INT)
BEGIN
    SELECT  state_id, state_name, country_id
    FROM    country_state
    WHERE   state_id = inStateId; 
END$$

-- Create customer_get_customer stored procedure
CREATE PROCEDURE customer_get_customer(IN inCustomerId INT)
BEGIN
    SELECT  * 
    FROM    customer
    WHERE   customer_id = inCustomerId;
END$$

-- Create beehive_get_beehive_latest_status: get latest health status
CREATE PROCEDURE beehive_get_beehive_latest_status(IN inBeehiveId INT)
BEGIN
    SELECT  * 
    FROM    beehive_health_status
    WHERE   beehive_id = inBeehiveId
    ORDER BY added_on DESC LIMIT 1;
END$$
        
CREATE PROCEDURE beehive_update_cluster_location(IN inClusterId INT, IN inLocationId INT, IN inClusterLon VARCHAR(16), IN inClusterLat VARCHAR(16), IN inModificationDate DATE)
BEGIN
    INSERT INTO cluster_location(cluster_id, location_id, cluster_dms_lon, cluster_dms_lat, added_on)
      VALUES (inClusterId, inLocationId, inClusterLon, inClusterLat, inModificationDate);
END$$

-- Create beehive_get_beehive_actions: get actions performed by the beekeeper
CREATE PROCEDURE beehive_get_beehive_actions(IN inBeehiveId INT, IN inStartDate DATETIME, IN inEndDate DATETIME)
BEGIN
    SELECT  * 
    FROM    beehive_actions
    WHERE   beehive_id = inBeehiveId
    AND     added_on BETWEEN inStartDate AND inEndDate
    ORDER BY added_on DESC;
END$$

CREATE PROCEDURE meteo_get_stations()
BEGIN
    SELECT *
    FROM meteo_station
    ORDER BY station_name;
END$$

CREATE PROCEDURE meteo_get_station_details(IN inStationId INT)
BEGIN
    SELECT *
    FROM meteo_station
    WHERE station_id = inStationId;
END$$

CREATE PROCEDURE meteo_get_station_data(IN inStationId INT, IN inMonth VARCHAR(8), IN inYear VARCHAR(8))
BEGIN
    SELECT *
    FROM meteo_station_data
    WHERE station_id = inStationId
    AND meteo_month = inMonth AND meteo_year = inYear
    ORDER BY meteo_day;
END$$

CREATE PROCEDURE meteo_add_data_entry(IN inStationId INT, inMeteoMonth VARCHAR(8), IN inMeteoYear VARCHAR(8), IN inMeteoDay VARCHAR(8), IN inMeanTemp FLOAT, IN inHighTemp FLOAT, IN inHighTempTime FLOAT,IN inLowTemp FLOAT, IN inLowTempTime FLOAT, IN inHeatDegDays FLOAT, IN inCoolDegDays FLOAT, IN inRain FLOAT, IN inAvgWindSpeed FLOAT, IN inMaxWindSpeed FLOAT,IN inMaxWindSpeedTime FLOAT, IN inWindDomDir VARCHAR(8))
BEGIN
    INSERT 
    INTO    meteo_station_data (station_id, meteo_month, meteo_year, meteo_day, mean_temp, high_temp, high_temp_time, low_temp, low_temp_time, heat_deg_days, cool_deg_days, rain, avg_wind_speed, max_wind_speed, max_wind_speed_time, dom_dir, added_on)
    VALUES (inStationId, inMeteoMonth, inMeteoYear, inMeteoDay, inMeanTemp, inHighTemp, inHighTempTime, inLowTemp, inLowTempTime, inHeatDegDays, inCoolDegDays, inRain, inAvgWindSpeed, inMaxWindSpeed, inMaxWindSpeedTime, inWindDomDir, NOW());
END$$

-- Change back DELIMITER to ;
DELIMITER ;
