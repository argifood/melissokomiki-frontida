<?php

class Meteo       
{
    
    public static function GetMeteoStations()
    {

        // Build SQL query
        $sql = 'CALL meteo_get_stations()';

        // Build the parameters array
        $params = array();

        // Execute the query and return the results
        return DatabaseHandler::GetAll($sql, $params);
    }
    
    public static function GetMeteoStationDetails($stationId)
    {

        // Build SQL query
        $sql = 'CALL meteo_get_station_details(:station_id)';

        // Build the parameters array
        $params = array('station_id' => $stationId);

        // Execute the query and return the results
        return DatabaseHandler::GetRow($sql, $params);
    }
    
    public static function GetMeteoStationData($stationId, $month, $year)
    {

        // Build SQL query
        $sql = 'CALL meteo_get_station_data(:station_id, :meteo_month, :meteo_year)';

        // Build the parameters array
        $params = array('station_id' => $stationId,
                        'meteo_month' => $month,
                        'meteo_year' => $year
                        );

        // Execute the query and return the results
        return DatabaseHandler::GetAll($sql, $params);
    }
    
    public static function AddMeteoDataEntry($stationId, $MeteoMonth, $MeteoYear, $MeteoDay, $MeanTemp, $HighTemp, $HighTempTime, $LowTemp, $LowTempTime, $HeatDegDays, $CoolDegDays, $Rain, $AvgWindSpeed, $MaxWindSpeed, $MaxWindSpeedTime, $WindDomDir)
    {

        // Build SQL query
        $sql = 'CALL meteo_add_data_entry(:station_id, :meteo_month, :meteo_year, :meteo_day, :mean_temp, :high_temp, :high_temp_time, :low_temp, :low_temp_time, :heat_deg_days, :cool_deg_days, :rain, :avg_wind_speed, :max_wind_speed, :max_wind_speed_time, :dom_dir)';

        // Build the parameters array
        $params = array(
            'station_id' => $stationId,
            'meteo_month' => $MeteoMonth,           
            'meteo_year' =>  $MeteoYear,
            'meteo_day' =>  $MeteoDay,
            'mean_temp' => $MeanTemp,
            'high_temp' => $HighTemp,
            'high_temp_time' => $HighTempTime,
            'low_temp' => $LowTemp,
            'low_temp_time' => $LowTempTime,
            'heat_deg_days' => $HeatDegDays,
            'cool_deg_days' => $CoolDegDays,
            'rain' => $Rain,
            'avg_wind_speed' => $AvgWindSpeed,
            'max_wind_speed' => $MaxWindSpeed,
            'max_wind_speed_time' => $MaxWindSpeedTime,
            'dom_dir' => $WindDomDir);

        // Execute the query
        return DatabaseHandler::Execute($sql, $params);
    }

    


}

?>
